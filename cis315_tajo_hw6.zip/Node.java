// Ouermi Timbwaoga Aime Judicael 
// course: cis 315
// Lab 2 hw6
* This a Character Node class
*/

public class Node
{
	int data; // hold value os node
	Node next; // pointer
	
	public Node(int da) // constructor
	{data = da;} // initialize data
	
	// public toString()
	public void displayNode() // display the chractere
	{System.out.print(data);}
}