/*
*Name: Ouermi Timbwaoga Aime Judicael
*Course: cis315
*Instructor: Chris Wilson
* hw 2 lab 1
*/
public class Link
{
	int data; // hold value os node
	Link next; // pointer
	
	public Link(int da) // constructor
	{data = da;} // initialize data
	
	// public toString()
	public void displayLink() // display the chractere
	{System.out.print(data);}

}